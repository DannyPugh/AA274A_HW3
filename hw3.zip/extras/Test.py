import numpy as np
# from numpy.lib.function_base import append
# from PlotFunctions import *
# from ExtractLines import FitLine
# import matplotlib.pyplot as plt

# theta = np.array([])


# A = np.array([1,2,3,4,5,6,7,8,9])
# print(A)
# print(A[(2-1):(len(A)-(2-1))])
# print(len(A)-(2-1))
# print(A[len(A)-(2-1)])


# 0,1,2   ,3,4,5,6,7,8,9
#         ,3
#         ,0,1,2,3,4,5,6