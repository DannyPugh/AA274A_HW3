# import numpy as np
# from numpy.lib.function_base import append
# from PlotFunctions import *
# from ExtractLines import FitLine
# import matplotlib.pyplot as plt

# theta = np.array([])